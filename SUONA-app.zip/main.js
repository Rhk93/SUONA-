const {app,BrowserWindow,shell}=require('electron');const path=require('path');
function crea(){const w=new BrowserWindow({width:1200,height:860,backgroundColor:'#05051a',autoHideMenuBar:true,icon:path.join(__dirname,'www','icon-512.png')});
 w.loadFile(path.join(__dirname,'www','index.html'));
 w.webContents.setWindowOpenHandler(({url})=>{shell.openExternal(url);return{action:'deny'}})}
app.whenReady().then(crea);
app.on('window-all-closed',()=>{if(process.platform!=='darwin')app.quit()});
app.on('activate',()=>{if(!BrowserWindow.getAllWindows().length)crea()});
